// Dependency-free NONCE admission check (no ethers, no /tmp files).
// Prints: paused=<true|false> totalSupply=<n> at <ISO time>
const FM = '0x7538ba8C1A82E9706dB6d2463C15f69ADc01a17e';
const NFT = '0x053259A3D30E63d9447E3d90813C6a494bcB398a';
const PAUSED_SEL = '0x5c975abb'; // keccak256("paused()")[:4]
const SUPPLY_SEL = '0x18160ddd'; // keccak256("totalSupply()")[:4]
async function ethCall(to, data) {
  const res = await fetch('https://bsc-dataseed2.binance.org/', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_call', params: [{ to, data }, 'latest'] }) });
  const j = await res.json();
  return j.result;
}
const p = await ethCall(FM, PAUSED_SEL);
const paused = p !== null && parseInt(p.slice(-2), 16) === 1;
const s = await ethCall(NFT, SUPPLY_SEL);
console.log('paused=' + paused + ' totalSupply=' + parseInt(s, 16) + ' at ' + new Date().toISOString());
