import sys, json, subprocess
clauses = json.load(open(sys.argv[1]))
out = sys.argv[2]
secs = int(sys.argv[3]) if len(sys.argv) > 3 else 300
n = max(abs(l) for c in clauses for l in c)
cnf = '/home/hatch/workspace/nonce_eth/kissat_input10.cnf'
with open(cnf, 'w') as f:
    f.write(f'p cnf {n} {len(clauses)}\n')
    for cl in clauses:
        f.write(' '.join(map(str, cl)) + ' 0\n')
print(f'kissat input: {len(clauses)} clauses, {n} vars, timeout {secs}s', flush=True)
r = subprocess.run(['/home/hatch/workspace/nonce_eth/kissat/build/kissat', cnf],
                   capture_output=True, text=True, timeout=secs + 60)
print('kissat exit:', r.returncode, 'tail:', r.stdout[-300:], flush=True)
if 's SATISFIABLE' in r.stdout:
    model = {}
    for line in r.stdout.splitlines():
        if line.startswith('v '):
            for tok in line[2:].split():
                lit = int(tok)
                if lit == 0: continue
                model[abs(lit)] = '1' if lit > 0 else '0'
    a = ''.join(model.get(v, '0') for v in range(1, n + 1))
    bad = sum(1 for c in clauses if not any((a[abs(l)-1] == '1') == (l > 0) for l in c))
    print('assignment length:', len(a), 'bad clauses:', bad, flush=True)
    if bad == 0 and len(a) == n:
        open(out, 'w').write(a)
        print('ASSIGNMENT_SAVED', flush=True)
