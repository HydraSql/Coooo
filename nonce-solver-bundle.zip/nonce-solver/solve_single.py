import sys, json
from pysat.solvers import Solver
clauses = json.load(open(sys.argv[1]))
out = sys.argv[2]
name = sys.argv[3]
n = max(abs(l) for c in clauses for l in c)
with Solver(name=name, bootstrap_with=clauses) as s:
    if s.solve():
        model = s.get_model()
        # build assignment from model dict
        m = {abs(v): (v > 0) for v in model}
        a = ''.join('1' if m.get(v, False) else '0' for v in range(1, n + 1))
        bad = sum(1 for c in clauses if not any((a[abs(l)-1] == '1') == (l > 0) for l in c))
        print(f'{name}: len {len(a)} bad {bad}', flush=True)
        if bad == 0 and len(a) == n:
            open(out, 'w').write(a)
            print('ASSIGNMENT_SAVED', flush=True)
    else:
        print(f'{name}: UNSAT', flush=True)
