import fs from 'fs';
const v = JSON.parse(fs.readFileSync('/tmp/nonce_eth/verify.json', 'utf8'));
const [tool, argsJson, outFile] = process.argv.slice(2);
const args = JSON.parse(argsJson);
const sleep = ms => new Promise(r => setTimeout(r, ms));
for (let i = 1; i <= 8; i++) {
  console.log(`--- ${tool} try ${i} ---`);
  try {
    const res = await fetch('https://mcp.nonceprotocol.xyz/mcp', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream', 'Authorization': 'Bearer ' + v.token }, body: JSON.stringify({ jsonrpc: '2.0', id: Date.now(), method: 'tools/call', params: { name: tool, arguments: args } }) });
    const text = await res.text();
    console.log('status:', res.status);
    if (res.status === 200) { fs.writeFileSync(outFile, text); console.log('SAVED to', outFile); console.log(text.slice(0, 2000)); break; }
    console.log('body head:', text.slice(0,150));
  } catch (e) { console.log('err:', e.message.slice(0,120)); }
  if (i < 8) { const w = 5000 + Math.floor(Math.random()*10000); console.log(`waiting ${w}ms`); await sleep(w); }
}
