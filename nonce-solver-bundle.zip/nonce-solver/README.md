# NONCE Solver Bundle — yang berhasil (#17 dan #18)

Solver ini memenangkan NONCE Genesis #2363 (attempt #17, 27 Okt 2026 ~06:10 WIB)
dan #3383 (attempt #18, ~06:13 WIB), keduanya rarity Uncommon, dengan benchmark
`nonce-logic-balanced-384-24`: 24 fragmen, 6912 klausa, 5 literal/klausa,
384 variabel, deadline 900 detik. Di kedua attempt, solver **cd195** menemukan
assignment 384 karakter yang terverifikasi (0 klausa salah) dalam hitungan detik
setelah fragmen terkumpul. Kissat ikut jalan paralel sebagai cadangan, tapi
tidak sempat menang di kedua attempt itu.

## Isi bundle

- `run18.mjs` — file persis yang dipakai attempt #18 (terbukti menang).
  Mengumpulkan 24 fragmen (4 worker paralel) via `inspect_fragment`,
  memeriksa jumlah klausa = 6912, lalu menjalankan 2 solver paralel,
  memverifikasi assignment (panjang harus 384, 0 klausa salah),
  lalu `submit_artifact` sampai 5 detik sebelum deadline.
- `solve_single.py` — solver pemenang. Pemakaian:
  `python solve_single.py <clauses.json> <assignment.txt> cd195`
  Menghitung jumlah variabel dari klausa, memakai PySAT, memverifikasi
  assignment sebelum menulis file. Solver lain bisa dipakai dengan mengganti
  nama solver PySAT di argumen ketiga.
- `kissat_solve10.py` — runner Kissat (cadangan). Menulis CNF, menjalankan
  binary `kissat`, mem-parsing model, memverifikasi sebelum menulis file.
- `kissat` — binary Kissat yang dipakai (Linux x86_64).
- `mcp_retry.mjs` — helper MCP dengan retry + jitter, pemakaian:
  `node mcp_retry.mjs <tool> '<argsJson>' <outFile>`
  Membaca token dari `/tmp/nonce_eth/verify.json`. Tool yang dipakai di alur:
  `prepare_attempt`, `start_attempt`, `attempt_status`, `mint_transaction`.
- `check_admission.mjs` — cek read-only admission FreeMint:
  `node check_admission.mjs` → `paused=<true|false> totalSupply=<n>`
  (RPC publik BSC, tanpa wallet, tanpa secret, tanpa transaksi).

## Yang TIDAK ada di bundle (sengaja)

Tidak ada token MCP, signature, capability, attemptId aktif, wallet address,
atau Agent ID. Semua itu dibuat baru per attempt dan hanya boleh hidup di
`/tmp/nonce_eth/` (chmod 600), jangan pernah dimasukkan ke bundle, repo,
atau chat. File attempt-spesifik (`verify.json`, `start_attempt*.json`,
`start_args*.json`, `prepare_args*.json`, `idempotencyKey*.txt`) juga tidak
ikut — buat ulang tiap attempt.

## Setup

1. Node.js 22+ dan Python 3.
2. Buat venv dan instal PySAT:
   `python3 -m venv venv && venv/bin/pip install python-sat`
3. Kissat: binary sudah ikut di bundle. `kissat_solve10.py` masih menunjuk
   ke path lama `/home/hatch/workspace/nonce_eth/kissat/build/kissat` dan
   file CNF `/home/hatch/workspace/nonce_eth/kissat_input10.cnf` — ubah
   kedua path itu ke lokasi bundle kamu, atau letakkan binary di path lama.
4. `run18.mjs` masih menunjuk ke `/tmp/nonce_eth/venv/bin/python`,
   `/tmp/nonce_eth/solve_single.py`, dan `/tmp/nonce_eth/kissat_solve10.py`
   — sesuaikan path itu, atau letakkan file-file ini di `/tmp/nonce_eth/`.

## Alur pakai (per attempt, urut)

1. Cek admission (`check_admission.mjs`): lanjut hanya kalau `paused=false`.
2. Auth MCP: ambil challenge, tanda tangani EIP-712 SignIn lewat wallet,
   verifikasi (body harus berisi `challenge`, signature TANPA prefix `0x`,
   128 hex char, `signatureRecovery` "00"/"01"). Token berlaku 1 jam.
   Kalau verifikasi gagal karena signature, ambil challenge BARU sebelum
   retry — challenge yang gagal terverifikasi tampaknya hangus.
3. `prepare_attempt` dengan 4 field: `wallet`, `idempotencyKey` (UUID baru),
   `beneficiary` (= wallet), `agentId` (string desimal).
   Catat benchmark dari hasil prepare (fragmen/klausa/variabel bisa berubah
   antar attempt — jangan asumsi sama dengan #17/#18).
4. Verifikasi StartAuthorization: `message.attemptId` harus =
   `keccak256(UTF8(attemptId))`, wallet cocok (case-insensitive), domain
   `verifyingContract` = FreeMint resmi `0x7538ba8C1A82E9706dB6d2463C15f69ADc01a17e`,
   `mintPrice` = "0", `failureFee` = "0".
5. Tanda tangani StartAuthorization: preview harus pakai file objek
   `startWalletRequest` LENGKAP (`{method, params}`), BUKAN hanya raw typed
   data `params[1]` — yang raw gagal di wallet dengan error 953004.
   Lalu `start_attempt` → state ACTIVE, catat deadline.
6. Adaptasi `run18.mjs` ke benchmark attempt itu dengan sed TERTARGET saja
   (identifier dan angka benchmark), lalu `node --check` dan grep bahwa
   literal lama sudah hilang. Jangan pernah blind-sed (pernah merusak
   literal 6912 menjadi 6913). Jalankan run, pantau baris `RESULT:`.
7. Kalau `VERIFIED_WIN`: panggil `mint_transaction`, verifikasi
   MintAuthorization (kontrak FreeMint/NFT resmi, value 0, wallet dan
   Agent ID cocok), preview lewat wallet (harus bersih: hanya +1 NFT ke
   wallet kamu, value 0, tanpa authority/allowance changes, tanpa risiko),
   baru eksekusi, lalu verifikasi receipt (status 0x1, Transfer tokenId,
   ownerOf = wallet kamu, balance bertambah).
   Perhatian: tokenId di preview BUKAN otoritatif — di #17 preview
   memprediksi #3365 tapi Transfer sebenarnya #2363, di #18 preview
   #5161 tapi sebenarnya #3383. Yang benar adalah Transfer on-chain.

## Catatan kegagalan yang dipelajari

- 4 solver paralel di 2 core = semuanya lebih lambat. Portofolio ramping
  (cd195 + Kissat) yang menang.
- Solver sekuensial tanpa timeout per solver bisa membuat solver kedua
  tidak pernah kebagian waktu.
- `/tmp` bisa hilang saat runtime restart — simpan script di direktori
  durable, dan siapkan langkah re-auth + rebuild `/tmp` dari sana.
- Deadline attempt bersifat mutlak: kalau proses mati mendekati deadline,
  attempt itu praktis hilang meski status masih ACTIVE dan receipt null.
