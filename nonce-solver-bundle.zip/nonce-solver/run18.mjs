import fs from 'fs';
import { spawn } from 'child_process';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const v = JSON.parse(fs.readFileSync('/tmp/nonce_eth/verify.json', 'utf8'));
const s = JSON.parse(fs.readFileSync('/tmp/nonce_eth/start_attempt18.json', 'utf8'));
const inner = JSON.parse(s.result.content[0].text);
const cap = inner.capability;
const attemptId = inner.attemptId;
const DEADLINE = Date.parse(inner.deadline);
console.log('attempt', attemptId, 'deadline', inner.deadline, 'now', new Date().toISOString());

async function fetchFrag(fid) {
  const body = JSON.stringify({ jsonrpc: '2.0', id: Date.now(), method: 'tools/call', params: { name: 'inspect_fragment', arguments: { attemptId, capability: cap, fragmentId: fid } } });
  for (let t = 1; t <= 14; t++) {
    if (Date.now() > DEADLINE - 130000) return null;
    try {
      const res = await fetch('https://mcp.nonceprotocol.xyz/mcp', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream', 'Authorization': 'Bearer ' + v.token }, body });
      const text = await res.text();
      if (res.status === 200 && !text.includes('SERVICE_UNAVAILABLE') && !text.includes('"isError":true')) {
        return JSON.parse(JSON.parse(text).result.content[0].text);
      }
    } catch (e) {}
    await sleep(800 + Math.floor(Math.random()*1300));
  }
  return null;
}

const all = [];
const queue = [...Array(24).keys()];
async function worker() {
  while (queue.length > 0 && Date.now() < DEADLINE - 130000) {
    const fid = queue.shift();
    const f = await fetchFrag(fid);
    if (f) { all.push(f); console.log(`fragment ${fid}: OK (${all.length}/24)`); fs.writeFileSync('/tmp/nonce_eth/fragments13.json', JSON.stringify(all)); }
    else { console.log(`fragment ${fid}: FAILED`); if (Date.now() < DEADLINE - 180000) queue.push(fid); }
  }
}
await Promise.all([worker(), worker(), worker(), worker()]);
console.log(`collected ${all.length}/24, time left ms: ${DEADLINE - Date.now()}`);
if (all.length !== 24) { console.log('RESULT: INCOMPLETE_FRAGMENTS - no submission'); process.exit(0); }
all.sort((a,b) => a.fragment.fragmentId - b.fragment.fragmentId);
const clauses = [];
for (const f of all) for (const c of f.fragment.clauses) clauses.push(c);
console.log('clauses:', clauses.length);
if (clauses.length !== 6912) { console.log('RESULT: CLAUSE_COUNT_MISMATCH'); process.exit(0); }
fs.writeFileSync('/tmp/nonce_eth/clauses18.json', JSON.stringify(clauses));
const solveSecs = Math.max(30, Math.floor((DEADLINE - Date.now()) / 1000) - 20);
console.log('solve budget secs:', solveSecs);
// 2 cores only: nonce_solver (component split, mcb+cd195) + WalkSAT, each in its own
// process group so cleanup kills pool children too. Bits go to stdout -> file.
const p2 = spawn('timeout', [String(solveSecs + 30), '/home/hatch/workspace/nonce_eth/venv/bin/python', '/tmp/nonce_eth/solve_single.py', '/tmp/nonce_eth/clauses18.json', '/tmp/nonce_eth/assignment18_cd195.txt', 'cd195'], { cwd: '/tmp/nonce_eth', detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
const p3 = spawn('timeout', [String(solveSecs + 30), '/home/hatch/workspace/nonce_eth/venv/bin/python', '/tmp/nonce_eth/kissat_solve10.py', '/tmp/nonce_eth/clauses18.json', '/tmp/nonce_eth/assignment18_kissat.txt', String(solveSecs)], { cwd: '/tmp/nonce_eth', detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
p2.stdout.on('data', d => process.stdout.write('[walksat] ' + d));
const files = ['/tmp/nonce_eth/assignment18_cd195.txt', '/tmp/nonce_eth/assignment18_kissat.txt'];
let assignment = null;
while (Date.now() < DEADLINE - 15000) {
  for (const fp of files) {
    if (fs.existsSync(fp)) {
      const a = fs.readFileSync(fp, 'utf8').trim();
      if (a.length === 384) {
        let bad = 0;
        for (const cl of clauses) { let ok = false; for (const lit of cl) if ((a[Math.abs(lit)-1] === '1') === (lit > 0)) { ok = true; break; } if (!ok) bad++; }
        console.log('verify', fp, 'bad:', bad);
        if (bad === 0) { assignment = a; break; }
        else fs.unlinkSync(fp);
      }
    }
  }
  if (assignment) break;
  await sleep(3000);
}
for (const p of [p2,p3]) { try { process.kill(-p.pid, 'SIGKILL'); } catch {} try { p.kill(); } catch {} }
if (!assignment) { console.log('RESULT: SOLVE_TIMEOUT - no submission'); process.exit(0); }
let submitted = null;
while (Date.now() < DEADLINE - 5000) {
  try {
    const res = await fetch('https://mcp.nonceprotocol.xyz/mcp', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream', 'Authorization': 'Bearer ' + v.token }, body: JSON.stringify({ jsonrpc: '2.0', id: Date.now(), method: 'tools/call', params: { name: 'submit_artifact', arguments: { attemptId, capability: cap, artifact: { assignment }, nonce: '0' } } }) });
    const text = await res.text();
    console.log('submit status:', res.status, 'body:', text.slice(0, 1500));
    if (res.status === 200) { submitted = text; break; }
  } catch (e) { console.log('submit err'); }
  await sleep(1500);
}
console.log('RESULT:', submitted ? 'SUBMITTED' : 'SUBMIT_NOT_COMPLETED');
